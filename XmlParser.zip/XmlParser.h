#include <iostream>
#include <ctype.h>
#include <string.h>
#include <cstring>
#include <fstream>
#include <string>
#include <cstdlib>
#include <time.h> 
#pragma warning(disable:4996)
using namespace std;

int getFirstDelimiterIndex(const char* txt, const char* delimiters);
int getLastDelimiterIndex(const char* txt, const char* delimiters);
int strncasecmp(const char* s1, const char* s2, size_t n);
const char* stristr(const char* haystack, const char* needle);
int random(int min, int max);

typedef struct Attribute {
	char* key;
	char* value;
	Attribute* next;
} Attribute;

typedef struct Child {
	char* key;
	void* value; // Should be void, reason: Cannot be type XmlParser because it is not defined yet and also this structure is used in the XmlParser class
	Child* next;
} Child;

class XmlParser {
private:
	char* key;
	char* value;
	Attribute* attributes;
	Child* children;
	XmlParser* parent;
public:
	XmlParser();

	XmlParser(const char* xml, XmlParser* parent);

	Child* createChild();

	Attribute* create�ttribute(char* k = NULL, char* v = NULL);

	void parser(const char* xml, XmlParser* parent = NULL);

	void checkAndAssignIds(int count = 0);

	char* getAttributeValue(const char* key);

	Attribute* getAttribute(const char* key);

	int getChildrenCount();

	bool load(const char* fileName);

	bool exists(char* strFileName);

	void print(const int offset = 0);

	char* getValue(char* id, char* key);

	char* getKey();

	void printAttributes();

	bool setAttributeValue(char* id, char* key, char* value);

	void printChildrenAttributes(char* id);

	XmlParser* getChild(char* id, int n);

	char* getText(char* id);	

	bool deleteAttribute(char* id, char* key);

	bool addChild(char* id);

	~XmlParser();
};

